var socket = io("https://chatnhom16.herokuapp.com");

// socket.on("thongbao", function() {
//     alert("canh")
// });
socket.on("co-nguoi-dang-nhap", function() {
    alert("Someone has logged into this account!!!");

});

socket.on("taikhoanchuadangki", function() {
    alert("Username is incorrect or not registered!!!");
});

socket.on("server-send-tkhoan-da-dangki", function() {
    alert("Login Fail!!!");
});

socket.on("server-send-danhsach-Users", function(data) {
    $("#boxContent").html("");
    data.forEach(function(i) {
        $("#boxContent").append("<div class='user'>" + i + "</div>");
    });
});

socket.on("server-send-dnhap-thanhcong", function(data) {
    $("#currentUser").html(data);
    $("#loginForm").hide(1000);
    $("#chatForm").show(2000);
    $("#registerForm").hide();
});

socket.on("server-send-dki-thanhcong", function(data) {
    $("#currentUser").html(data);
    $("#loginForm").hide();
    $("#chatForm").show(2000);
    $("#registerForm").hide(1000);
});

socket.on("server-send-mesage", function(data) {
    $("#listMessages").append("<div class ='ms' >" + "&nbsp;" + data.un + ": " + data.nd + "</div>");
});


$(document).ready(function() {
    $("#loginForm").show();
    $("#chatForm").hide();
    $("#registerForm").hide();


    $("#btnLogin").click(function() {
        socket.emit("client-send-Username", {
            ten: $("#txtUsername").val(),
            mk: $("#password").val()
        });
    });

    $("#btnLogout").click(function() {
        socket.emit("logout");
        $("#chatForm").hide(2000);
        $("#loginForm").show(1000);
        $("#registerForm").hide();
        alert("You have successfully logged out");
    });
    $("#dnthave").click(function() {
        socket.emit("go-register");
        $("#registerForm").show(2000);
        $("#loginForm").hide(1000);
        $("#chatForm").hide();

    });

    $("#btnRegister").click(function() {
        socket.emit("registernow", {
            ten: $("#txtRegistername").val(),
            matkhau: $("#txtpassword").val(),
            rematkhau: $("#txtrepassword").val()
        });
    });

    $("#btnSendMessage").click(function() {
        socket.emit("user-send-message", $("#txtMessage").val());
        $("#txtMessage").val("");

    });

});




particlesJS("particles-js", {
    "particles": {
        "number": {
            "value": 60,
            "density": {
                "enable": true,
                "value_area": 800
            }
        },
        "color": {
            "value": "#ffffff"
        },
        "shape": {
            "type": "circle",
            "stroke": {
                "width": 0,
                "color": "#000000"
            },
            "polygon": {
                "nb_sides": 5
            },
            "image": {
                "src": "img/github.svg",
                "width": 100,
                "height": 100
            }
        },
        "opacity": {
            "value": 0.1,
            "random": false,
            "anim": {
                "enable": false,
                "speed": 1,
                "opacity_min": 0.1,
                "sync": false
            }
        },
        "size": {
            "value": 6,
            "random": false,
            "anim": {
                "enable": false,
                "speed": 40,
                "size_min": 0.1,
                "sync": false
            }
        },
        "line_linked": {
            "enable": true,
            "distance": 150,
            "color": "#ffffff",
            "opacity": 0.1,
            "width": 2
        },
        "move": {
            "enable": true,
            "speed": 1.5,
            "direction": "top",
            "random": false,
            "straight": false,
            "out_mode": "out",
            "bounce": false,
            "attract": {
                "enable": false,
                "rotateX": 600,
                "rotateY": 1200
            }
        }
    },
    "interactivity": {
        "detect_on": "canvas",
        "events": {
            "onhover": {
                "enable": false,
                "mode": "repulse"
            },
            "onclick": {
                "enable": false,
                "mode": "push"
            },
            "resize": true
        },
        "modes": {
            "grab": {
                "distance": 400,
                "line_linked": {
                    "opacity": 1
                }
            },
            "bubble": {
                "distance": 400,
                "size": 40,
                "duration": 2,
                "opacity": 8,
                "speed": 3
            },
            "repulse": {
                "distance": 200,
                "duration": 0.4
            },
            "push": {
                "particles_nb": 4
            },
            "remove": {
                "particles_nb": 2
            }
        }
    },
    "retina_detect": true
});